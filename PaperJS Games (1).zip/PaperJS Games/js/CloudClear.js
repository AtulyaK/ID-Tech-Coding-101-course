//Sets the background image. In Brackets, hover your mouse over 
//the string text below to see the image that's being used.
var background = new Raster("images/cloudBackground.png", [400, 300]);

var startButton = new Raster("images/StartButton.png", [400, 400]);
startButton.visible = true;

//This runs when you click on the start button.
startButton.onClick = function(){
    startGame();
}

//Creates the player's paddle.
var player = new Raster("images/paddle.png", [400, 500]);
player.visible = false;
player.name = "player";
var speed = 5;

//Controls the player's paddle movement when keys are pressed.
player.onFrame = function(event){
    if(Key.isDown('left') && player.position.x > 65.5){
        player.translate(-speed, 0);
    }
    if(Key.isDown('right') && player.position.x < 735){
        player.translate(speed, 0);
    }
}

//Sets the enemy images.
var enemy1 = new Raster("images/storm.png", [75, 150]);
enemy1.visible = false;
enemy1.name = "enemy";

var enemy2 = new Raster("images/sad_cloud.png", [400, 150]);
enemy2.visible = false;
enemy2.name = "enemy";

var enemy3 = new Raster("images/happy_cloud.png", [700, 150]);
enemy3.visible = false;
enemy3.name = "enemy";

//Set up the soap bubble.
var raindrop = new Raster("images/raindrop.png", [player.position.x, player.position.y - 30]);
raindrop.visible = false;
raindrop.canMove = false;
raindrop.speed = [7, -7];
raindrop.onFrame = function(event){
    //Makes the raindrop bounce if it hits a wall.
   if(this.position.x > 780){
        this.speed[0] = - this.speed[0];
    }
    
    if(this.position.x < 0){
        this.speed[0] = - this.speed[0];
    }
    if(this.position.y < 0){
        this.speed[1] = - this.speed[1];
    }
    if(this.position.y > 600){
        this.canMove = false;
        raindrop.speed = [7, -7];
    }
}

raindrop.reverseSpeed = function(){
    this.speed[1] = - this.speed[1];
}


//The function that runs when the start button is clicked.
function startGame(){
    startButton.visible = false;
    player.visible = true;
    raindrop.visible = true;
    background.visible = true;
    background.insertBelow(player);
    enemy1.visible = true;
    enemy2.visible = true;
    enemy3.visible = true;
}

function onKeyUp(event){
    console.log(event.key);
    if(event.key == "space"){
        var randomChance = Math.random();
        console.log(randomChance);
        if(randomChance > 0.5){
            raindrop.speed[0] = - raindrop.speed[0];
        }   
        raindrop.speed[1] = -7;
        raindrop.canMove = true;
        console.log(raindrop.canMove);
    }
}

//A list of things that the soap bubble can bounce off of.
bounceList = [];
bounceList.push(player);
bounceList.push(enemy1);
bounceList.push(enemy2);
bounceList.push(enemy3);
console.log(bounceList);

//Main game loop.
function onFrame(event){
    console.log("going");
    if(raindrop.canMove){
        console.log("true, I should move.");
        raindrop.translate(raindrop.speed);
    }
    else{
        raindrop.position = [player.position.x, player.position.y - 25];
    }
    collisionCheck();
}

//Check if the soap bubble hits anything.
function collisionCheck(){
    for(var i = 0; i < bounceList.length; i++){
        if(raindrop.bounds.intersects(bounceList[i].bounds)){
            if(bounceList[i].name == "enemy"){
                bounceList[i].remove();
                bounceList.splice(i, 1);
            }
            else{
                raindrop.position.y -= 35;
            }
            raindrop.reverseSpeed();
        }
    }
}